#ifndef FLATCC_PORTABLE_H
#define FLATCC_PORTABLE_H

#ifdef __cplusplus
extern "C" {
#endif

#include "flatcc/portable/portable_basic.h"

#ifdef __cplusplus
}
#endif

#endif /* FLATCC_PORTABLE_H */
